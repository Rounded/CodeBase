var win = Titanium.UI.currentWindow;

var webView = Titanium.UI.createWebView({html:'<div style="font-family:Helvetica"><b>Q: What is LASIK and what does LASIK mean?</b><br />A: LASIK surgery is a surgical procedure used to correct a wide range of nearsightedness, farsightedness and astigmatism. A thin layer of the cornea is lifted to create a protective flap. The cool beam of the excimer laser re-shapes the cornea and the flap is then returned for a quick, natural recovery. Patients experience little discomfort and can return to work the next day. LASIK stands for "Laser in situ Keratomileusis". It is a cool beam laser that reshapes the cornea without destroying the adjacent cell layers.<br /><br /><b>Q: Are LASIK and/or PRK FDA approved procedures?</b> <br />A: Yes! In 1995, the FDA approved the use of the excimer laser. LASIK’s popularity has grown and is now the procedure of choice worldwide.<br /><br /><b>Q: Is LASIK covered by insurance?</b> <br />A: LASIK is considered an elective procedure and is generally not covered by insurance. However, we encourage you to contact your insurance provider to inquire about coverage; you may also consider contacting your human resources manager if you have a flexible spending account. Many patients choose to use this account for elective procedures.<br /><br /><b>Q: Does the procedure hurt?</b> <br />A: The actual procedure does not hurt; numbing drops are applied to the eyes. You may experience a slight pressure sensation during the procedure. After the procedure, some patients may experience some discomfort, such as mild irritation, scratchiness, dry eyes, watery eyes, redness or sensitivity to light. We recommend sleeping and keeping the eyes closed for the first 4 to 5 hours to help reduce any mild discomfort.<br /><br /><b>Q: What are the side effects?</b> <br />A: As with any surgical procedure, there are possible side effects. The most common to LASIK are sensitivity to light, night glare, dry eyes and mild irritation. Most of these are temporary and will subside within 2 to 3 days. Others may last up to six months.<br /><br /><b>Q: What are the long-term effects?</b> <br />A: There is no evidence suggesting any long-term risks associated with LASIK.\n\nQ: Do you give patients any type of anesthetic and/or sedative for the LASIK procedure? \nA: Yes, we use numbing drops, not needles, for the eyes. You will also be able to take a mild sedative which will help you relax. However, you will need to remain awake during the procedure.<br /><br /><b>Q: How long will I be off work?</b> <br />A: You may return to work and resume your normal activities when you feel able. Most patients return to work within 24 hours of their procedure. You should restrict yourself from wearing eye make-up for the first 7 days, showering (baths only for the first 12 hours), water sports, such as swimming, for 1 week and dirt or dust prone environments for a period of two weeks, unless you wear protective eyewear.<br /><br /><b>Q: Am I a good candidate for laser vision correction?</b> <br />A: The only way to know whether or not you are a good candidate for a refractive procedure is to be examined by a qualified refractive specialist. Your prescription or a brief screening examination provides only an estimate of your suitability. Several conditions can disqualify you from the procedure. Only with a comprehensive eye examination can you be confident of your suitability for LASIK.</div>'});

win.add(webView);

/*
var label = Titanium.UI.createLabel({
	text:'Q: What is LASIK and what does LASIK mean? \nA: LASIK surgery is a surgical procedure used to correct a wide range of nearsightedness, farsightedness and astigmatism. A thin layer of the cornea is lifted to create a protective flap. The cool beam of the excimer laser re-shapes the cornea and the flap is then returned for a quick, natural recovery. Patients experience little discomfort and can return to work the next day. LASIK stands for "Laser in situ Keratomileusis". It is a cool beam laser that reshapes the cornea without destroying the adjacent cell layers.  \n\nQ: Are LASIK and/or PRK FDA approved procedures? \nA: Yes! In 1995, the FDA approved the use of the excimer laser. LASIK’s popularity has grown and is now the procedure of choice worldwide. \n\nQ: Is LASIK covered by insurance? \nA: LASIK is considered an elective procedure and is generally not covered by insurance. However, we encourage you to contact your insurance provider to inquire about coverage; you may also consider contacting your human resources manager if you have a flexible spending account. Many patients choose to use this account for elective procedures. \n\nQ: Does the procedure hurt? \nA: The actual procedure does not hurt; numbing drops are applied to the eyes. You may experience a slight pressure sensation during the procedure. After the procedure, some patients may experience some discomfort, such as mild irritation, scratchiness, dry eyes, watery eyes, redness or sensitivity to light. We recommend sleeping and keeping the eyes closed for the first 4 to 5 hours to help reduce any mild discomfort. \n\nQ: What are the side effects?\n A: As with any surgical procedure, there are possible side effects. The most common to LASIK are sensitivity to light, night glare, dry eyes and mild irritation. Most of these are temporary and will subside within 2 to 3 days. Others may last up to six months. \n\nQ: What are the long-term effects?\nA: There is no evidence suggesting any long-term risks associated with LASIK.\n\nQ: Do you give patients any type of anesthetic and/or sedative for the LASIK procedure? \nA: Yes, we use numbing drops, not needles, for the eyes. You will also be able to take a mild sedative which will help you relax. However, you will need to remain awake during the procedure. \n\nQ: How long will I be off work? \n A: You may return to work and resume your normal activities when you feel able. Most patients return to work within 24 hours of their procedure. You should restrict yourself from wearing eye make-up for the first 7 days, showering (baths only for the first 12 hours), water sports, such as swimming, for 1 week and dirt or dust prone environments for a period of two weeks, unless you wear protective eyewear. \n\nQ: Am I a good candidate for laser vision correction? \nA: The only way to know whether or not you are a good candidate for a refractive procedure is to be examined by a qualified refractive specialist. Your prescription or a brief screening examination provides only an estimate of your suitability. Several conditions can disqualify you from the procedure. Only with a comprehensive eye examination can you be confident of your suitability for LASIK.',
	color:'#000',
	font:{
		fontFamily:'Helvetica Neue',
		fontSize:15
	},
	width:300,
	height:'auto',
	textAlign: 'left'
});
*/
/*

var scrollView = Titanium.UI.createScrollView({
    contentWidth:'auto',
    contentHeight:'auto',
    top:0,
    showVerticalScrollIndicator:true,
    showHorizontalScrollIndicator:true
});
var view = Ti.UI.createView({
    borderRadius:10,
    width:300,
    height: 'auto',
    top:10
});
view.add(label);
scrollView.add(view);
win.add(scrollView);
*/

