var win = Titanium.UI.currentWindow;

var label = Titanium.UI.createLabel({
	text:"Photorefractive Keratectomy, is a form of outpatient corneal surgery in which a surgeon removes the front surfaces of the cornea called the epithelium, and then reshapes the corneal bed with the laser in the same way as LASIK. After the procedure you will wear a soft contact lens (bandage lens) until the epithelial layer regenerates. Healing responses vary from patient to patient, but generally take between 3-5 days. This technique is usually used for people whose cornea may be too thin to allow for the creation of the corneal flap required for LASIK. PRK is used to correct nearsightedness (myopia), farsightedness (hyperopia), and astigmatism ",
	color:'#000',
	font:{
		fontFamily:'Helvetica Neue',
		fontSize:15
	},
	width:300,
	height:'auto',
	textAlign: 'left'
});

var scrollView = Titanium.UI.createScrollView({
    contentWidth:'auto',
    contentHeight:'auto',
    top:0,
    showVerticalScrollIndicator:true,
    showHorizontalScrollIndicator:true
});
var view = Ti.UI.createView({
    borderRadius:10,
    width:300,
    height: 'auto',
    top:10
});
view.add(label);
scrollView.add(view);
win.add(scrollView);

