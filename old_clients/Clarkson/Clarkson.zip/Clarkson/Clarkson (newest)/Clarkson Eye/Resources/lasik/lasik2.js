var win = Titanium.UI.currentWindow;


var label = Titanium.UI.createLabel({
	text:'The IntraLase Method is the 100% all-laser approach to creating your corneal flap; the thin flap of tissue that the doctor folds back in order to perform your LASIK procedure. Traditionally, doctors have used an instrument called a microkeratome for the creation of corneal flaps. The microkeratome is a hand-held blade that moves across the eye, cutting the corneal flap as it goes. While LASIK is extremely safe, if complications do occur the microkeratome is most often the cause. With the IntraLase Method, tiny pulses of light, a quadrillionth of a second each, pass harmlessly through the outer portion of your cornea and form a uniform layer of microscopic bubbles just beneath the surface of your eye. The exact dimensions of this layer of bubbles are determined by your doctor based on what’s best for your eye, and are computer controlled for maximum precision-things that are not possible with a hand-held blade. When it’s time for your LASIK treatment to be performed, your doctor easily separates the tissue where these bubbles occur and then folds it back, thus creating your corneal flap. When LASIK is complete, a flap created using the IntraLase Method is uniquely able to "lock" back into place. Your eye then begins to rapidly heal. Hundreds of thousands of procedures have been performed safely and effectively using the IntraLase Method.',
	color:'#000',
	font:{
		fontFamily:'Helvetica Neue',
		fontSize:15
	},
	width:300,
	height:'auto',
	textAlign: 'left'
});

var scrollView = Titanium.UI.createScrollView({
    contentWidth:'auto',
    contentHeight:'auto',
    top:0,
    showVerticalScrollIndicator:true,
    showHorizontalScrollIndicator:true
});
var view = Ti.UI.createView({
    borderRadius:10,
    width:300,
    height: 'auto',
    top:10
});
view.add(label);
scrollView.add(view);
win.add(scrollView);
