var win = Titanium.UI.currentWindow;


var label = Titanium.UI.createLabel({
	text:"The technology used in the iLASIK procedure is the combination of the previously mentioned IntraLase and CustomVue technology. In fact, all branches of the U.S. military and NASA recently approved LASIK for their servicemen and women, thanks to studies using iLASIK technology.\n\niLASIK uses computers/software to make an individual blueprint of your eyes; this blueprint is used to drive your laser correction and is what gives you a truly customized result. A laser is used to make a thin flap in your cornea and a second laser is used to make the correction to your cornea, based on your unique vision/eye characteristics.\n\nThe iLASIK procedure EXCLUSIVELY uses the IntraLase laser; it's part of what makes iLASIK vision correction unique. Eighty-one percent of patients choose bladeless LASIK over traditional LASIK with a blade when given the choice. The vast majority of iLASIK patients will see 20/20 OR BETTER after surgery ... That could be life changing!",
	color:'#000',
	font:{
		fontFamily:'Helvetica Neue',
		fontSize:15
	},
	width:300,
	height:'auto',
	textAlign: 'left'
});

var scrollView = Titanium.UI.createScrollView({
    contentWidth:'auto',
    contentHeight:'auto',
    top:0,
    showVerticalScrollIndicator:true,
    showHorizontalScrollIndicator:true
});
var view = Ti.UI.createView({
    borderRadius:10,
    width:300,
    height: 'auto',
    top:10
});
view.add(label);
scrollView.add(view);
win.add(scrollView);

