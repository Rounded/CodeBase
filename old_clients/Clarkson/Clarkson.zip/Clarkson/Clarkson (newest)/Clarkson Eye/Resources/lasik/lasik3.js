var win = Titanium.UI.currentWindow;


var label = Titanium.UI.createLabel({
	text:"CustomVue Individualized Laser Vision Correction was developed by VISX; recognized worldwide for bringing innovation and breakthrough technology to laser vision correction. Using WaveScan™-based digital technology, originally developed for use in high-powered telescopes to reduce distortions when viewing distant objects in space, doctors can now capture unique imperfections in each individual's vision that could not have been measured before using standard methods.\n\nThe information captured using the WaveScan technology is transferred to the laser, providing a new level of precision and accuracy. This new level of measurement provides 25 times more precision than with standard methods used for glasses and contact lenses.\n\nJust like a fingerprint, each person's vision is 100% unique to their eyes. Before the recent advancements in technology, doctors were only able to use standard measurement to correct vision. With the CustomVue procedure, no two \"prescriptions\" are identical. \n \n CustomVue can measure and correct the unique imperfections of each individual's vision and provide them with the potential to experience better vision than is possible with glasses and contact lenses-Personal Best Vision.",
	color:'#000',
	font:{
		fontFamily:'Helvetica Neue',
		fontSize:15
	},
	width:300,
	height:'auto',
	textAlign: 'left'
});

var scrollView = Titanium.UI.createScrollView({
    contentWidth:'auto',
    contentHeight:'auto',
    top:0,
    showVerticalScrollIndicator:true,
    showHorizontalScrollIndicator:true
});
var view = Ti.UI.createView({
    borderRadius:10,
    width:300,
    height: 'auto',
    top:10
});
view.add(label);
scrollView.add(view);
win.add(scrollView);

