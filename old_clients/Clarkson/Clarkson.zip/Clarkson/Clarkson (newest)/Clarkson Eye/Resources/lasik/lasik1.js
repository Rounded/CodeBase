var win = Titanium.UI.currentWindow;

var label = Titanium.UI.createLabel({
	text: 'You know we have experienced surgeons who have performed over 20,000 LASIK procedures. You know we use the latest LASIK technology. And you know we offer $0 down, 24-month, no-interest financing.\n\nBut did you know... LASIK is the procedure of choice for millions of active people worldwide. Visual freedom is available to you now and only takes a few minutes for a lifetime of enjoyment.\n\nSee the alarm clock in the morning, be active without glasses or contacts holding you back, look your very best.\n\nJoin the thousands of Clarkson Eyecare LASIK patients who know.',
	color:'#000',
	font:{
		fontFamily:'Helvetica Neue',
		fontSize:15
	},
	width:300,
	height:'auto',
	textAlign: 'left'
});

var scrollView = Titanium.UI.createScrollView({
    contentWidth:'auto',
    contentHeight:'auto',
    top:0,
    showVerticalScrollIndicator:true,
    showHorizontalScrollIndicator:true
});
var view = Ti.UI.createView({
    borderRadius:10,
    width:300,
    height: 'auto',
    top:10
});
view.add(label);
scrollView.add(view);
win.add(scrollView);



