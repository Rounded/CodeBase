//Global settings / variables
Titanium.UI.setBackgroundColor('#fff');
var nav = Titanium.UI.createTabGroup();

var callAlert = Titanium.UI.createAlertDialog({
    title: 'Call Clarkson Eyecare at',
    message: '888.393.2273',
    buttonNames: ['Call','Cancel']
});

callAlert.addEventListener('click', function(e)
{
	if(e.index == 0){
		Ti.Platform.openURL('tel:'+8883932273);
	}
	else{
		return;
	}
	
});

//*****About*********************************************************************
var aboutWindow = Titanium.UI.createWindow({
	barColor:'#1389d1',
	backgroundColor:'#fff',  
    title:'About'
});

//Call Button
var aboutCallButton = Titanium.UI.createButton({
	backgroundImage:'phone-btn.png',
	backgroundDisabledImage:'phone-btn.png',
	backgroundSelectedImage: 'phone-btn-d.png',
	width:52,
	height:39
});
	

	
aboutCallButton.addEventListener('click', function(e)
{
	callAlert.show();
});

aboutWindow.rightNavButton = aboutCallButton;

var aboutTab = Titanium.UI.createTab({  
    icon:'info.png',
    title:'About',
    window:aboutWindow
});

var aboutHeader = Ti.UI.createView({
	height:'auto',
	top:15
});

var aboutLabel = Titanium.UI.createLabel({
	color:'#000',
	text:'Clarkson Eyecare is the leading eye care provider in the St. Louis area. With great doctors, great prices, and the latest technology, you can trust your eyes to Clarkson Eyecare. St. Louis considers Clarkson Eyecare\'s optometrists and ophthalmologists the leaders for eye care and LASIK surgery.',
	font:{fontSize:17,fontFamily:'Helvetica Neue'},
	textAlign:'left',
	height: 'auto',
	width:300,
	left:5,
	top:15
});

var aboutCallLabel = Titanium.UI.createLabel({
	color:'blue',
	text:'Call us at 888.EYECARE',
	font:{fontSize:19,fontFamily:'Helvetica Neue'},
	textAlign:'left',
	height: 'auto',
	width:300,
	left:5,
	top:15
});

var aboutImg = Titanium.UI.createImageView({
	image: 'logo.gif',
	width:'auto',
	height:'auto',
	left: 5,
	top:38
	});

var aboutBar = Titanium.UI.createLabel({
	color:'white',
	backgroundColor: '#aaa',
	text:'  Call us at 888.EYECARE',
	font:{fontSize:16,fontFamily:'Helvetica Neue'},
	textAlign:'left',
	height:23,
	top:0
	
});

var aboutFooterBar = Titanium.UI.createLabel({
	color:'white',
	backgroundColor: '#555',
	text:'  Share with a friend',
	font:{fontSize:16,fontFamily:'Helvetica Neue'},
	textAlign:'left',
	height:53,
	bottom:0
	
});

var footerIcon1 = Titanium.UI.createImageView({
	image:'email_icon.png',
	height:'auto',
	right:-200
});


var footerIcon2 = Titanium.UI.createImageView({
	image:'twitter_icon.png',
	height:'auto',
	right:-255
});

var aboutRow1 = Ti.UI.createTableViewRow({
	hasChild: false,
	height:'auto',
	selectedBackgroundColor:'#fff'
	});
	
var aboutRow2 = Ti.UI.createTableViewRow({
	hasChild: false,
	height:30,
	backgroundColor:'red',
	bottom: 0
	});
	
//aboutRow1.removeEventListener();
	
aboutHeader.add(aboutImg);
aboutHeader.add(aboutBar);	
aboutRow1.add(aboutLabel);

var aboutTableView = Titanium.UI.createTableView({
	minRowHeight:'auto',
	separatorStyle:'none'
});
//Bug is somewhere in aboutrow1
aboutTableView.headerView = aboutHeader;
aboutTableView.appendRow(aboutRow1);

aboutFooterBar.add(footerIcon1);
aboutFooterBar.add(footerIcon2);


// add table view to the window
aboutWindow.add(aboutTableView);
aboutWindow.add(aboutFooterBar);

var shareAlert = Titanium.UI.createAlertDialog({
    title: 'Send with a Friend via:',
    buttonNames: ['Email','Twitter','Cancel']
});

shareAlert.addEventListener('click', function(e)
{
	if(e.index == 0){
		Ti.Platform.openURL('mailto:?Subject=Check-out%20Clarkson%20Eyecare');
	}
	else if(e.index == 1){
		Ti.Platform.openURL('http://www.twitter.com/clarksoneyecare');
	}
	else{
		return;
	}
	
});

aboutFooterBar.addEventListener('click', function(e){
	shareAlert.show();
});



//*****End About*********************************************************************

//*****Locations*********************************************************************	
var locationsWindow = Titanium.UI.createWindow({barColor:'#1389d1',  
    title:'Locations',
    url: 'locations.js'
});

//Call Button
var locationsCallButton = Titanium.UI.createButton({
	backgroundImage:'phone-btn.png',
	backgroundDisabledImage:'phone-btn.png',
	backgroundSelectedImage: 'phone-btn-d.png',
	width:52,
	height:39
	});
	
	
locationsCallButton.addEventListener('click', function(e)
{
	callAlert.show();
});




locationsWindow.rightNavButton = locationsCallButton;


var locationsTab = Titanium.UI.createTab({  
    icon:'KS_nav_mashup.png',
    title:'Locations',
    window:locationsWindow
});
//*****End Locations*********************************************************************

//*****Lasik*********************************************************************
var lasikWindow = Titanium.UI.createWindow({  
    title:'LASIK',
    barColor:'#1389d1'
});

//Call Button
var lasikCallButton = Titanium.UI.createButton({
	backgroundImage:'phone-btn.png',
	backgroundDisabledImage:'phone-btn.png',
	backgroundSelectedImage: 'phone-btn-d.png',
	width:52,
	height:39
	});
	
lasikCallButton.addEventListener('click', function(e)
{
	callAlert.show();
});

lasikWindow.rightNavButton = lasikCallButton;

var lasikTab = Titanium.UI.createTab({  
    icon:'lasik.png',
    title:'LASIK',
    window:lasikWindow
});

var lasikData = [
 {title:'About LASIK', hasChild:true, path:'lasik/lasik1.js'},
 {title:'IntraLase Technology', hasChild:true, path:'lasik/lasik2.js'},
 {title:'CustomVue Technology', hasChild:true, path:'lasik/lasik3.js'},
 {title:'iLASIK', hasChild:true, path:'lasik/lasik4.js'},
 {title:'PRK', hasChild:true, path:'lasik/lasik5.js'},
 {title:'LASIK FAQ', hasChild:true, path:'lasik/lasik6.js'}
 
];

var lasikTableView = Titanium.UI.createTableView({
 data:lasikData
});

lasikWindow.add(lasikTableView);

lasikTableView.addEventListener('click', function(e)
{
	if (e.rowData.path)
	{
		var win = null;
		if (Ti.Platform.name == "android") {
			win = Titanium.UI.createWindow({barColor:'#1389d1',
				url:e.rowData.path,
				title:e.rowData.title
			});	
		} else {
			win = Titanium.UI.createWindow({barColor:'#1389d1',
				url:e.rowData.path,
				title:e.rowData.title,
				backgroundColor:'#fff'
			});
		}

		lasikTab.open(win);
	}
});
//*****End Lasik*********************************************************************

//*****Survey*********************************************************************
var surveyWindow = Titanium.UI.createWindow({barColor:'#1389d1',  
    title:'Survey'
});

//Call Button
var surveyCallButton = Titanium.UI.createButton({
	backgroundImage:'phone-btn.png',
	backgroundDisabledImage:'phone-btn.png',
	backgroundSelectedImage: 'phone-btn-d.png',
	width:52,
	height:39
	});
	
surveyCallButton.addEventListener('click', function(e)
{
	callAlert.show();
});

surveyWindow.rightNavButton = surveyCallButton;

var surveyTab = Titanium.UI.createTab({  
    icon:'survey.png',
    title:'Survey',
    window:surveyWindow
});

var surveyData = [
 {title:'Patient Survey', hasChild:true, path:'survey1.js'},
 {title:'LASIK Survery', hasChild:true, path:'survey2.js'}
];

var surveyTableView = Titanium.UI.createTableView({
 data:surveyData
});

surveyWindow.add(surveyTableView);

surveyTableView.addEventListener('click', function(e)
{
	if (e.rowData.path)
	{
		var win = null;
		if (Ti.Platform.name == "android") {
			win = Titanium.UI.createWindow({barColor:'#1389d1',
				url:e.rowData.path,
				title:e.rowData.title
			});	
		} else {
			win = Titanium.UI.createWindow({barColor:'#1389d1',
				url:e.rowData.path,
				title:e.rowData.title,
				backgroundColor:'#fff'
			});
		}

		surveyTab.open(win);
	}
});

//*****End Survey*********************************************************************
//*****Start Special******************************************************************

var specialWindow = Titanium.UI.createWindow({barColor:'#1389d1',  
    title:'Special'
});

var specialLoaded = false;

var specialAlert = Titanium.UI.createAlertDialog({
    title: 'Network Error',
    message: 'Unable to load special',
    buttonNames: ['Reload','Cancel']
});

var specialRefreshButton = Titanium.UI.createButton({
	backgroundImage:'refresh-btn.png',
	backgroundDisabledImage:'refresh-btn.png',
	backgroundSelectedImage: 'refresh-btn-d.png',
	width:52,
	height:39
});

specialWindow.leftNavButton = specialRefreshButton;

specialRefreshButton.addEventListener('click', function(e)
{
 	doSpecial();
});

specialAlert.addEventListener('click', function(e)
{
	if(e.index == 0){
		doSpecial();
	}
	else{
		return;
	}
	
});
//Call Button
var specialCallButton = Titanium.UI.createButton({
	backgroundImage:'phone-btn.png',
	backgroundDisabledImage:'phone-btn.png',
	backgroundSelectedImage: 'phone-btn-d.png',
	width:52,
	height:39
	});
	
specialCallButton.addEventListener('click', function(e)
{
	callAlert.show();
});

specialWindow.rightNavButton = specialCallButton;

var specialImg = Titanium.UI.createImageView({
	width:360,
	top:5
	});

function doSpecial(){	
xhr = Titanium.Network.createHTTPClient();
xhr.setTimeout(10000);
xhr.onload = function() {
	//alert(this.responseText);
	specialImg.image = (this.responseText);
	specialWindow.add(specialImg);
	specialLoaded = true;
};
xhr.onerror = function(){
	specialAlert.show();
}
xhr.open('GET', 'http://www.clarksoneyecare.com/mobile_admin/image_to_phone.php',true);
xhr.send();	
}

specialWindow.addEventListener('focus', function() 
{	
	if(!specialLoaded){
			doSpecial();
	}

});



var specialTab = Titanium.UI.createTab({  
    icon:'specials.png',
    title:'Special',
    window:specialWindow
});

//*****End Special********************************************************************

//Create nav tab bar
if (Ti.Platform.name == "android") {
			nav.addTab(aboutTab);
			nav.addTab(locationsTab);  
			nav.addTab(lasikTab);  
			nav.addTab(surveyTab);  
			nav.addTab(specialTab);
			nav.setActiveTab(3); 
			nav.open();
		} else {
			nav.addTab(aboutTab);  
			nav.addTab(locationsTab);  
			nav.addTab(lasikTab);  
			nav.addTab(surveyTab);  
			nav.addTab(specialTab); 
			nav.open();
		}