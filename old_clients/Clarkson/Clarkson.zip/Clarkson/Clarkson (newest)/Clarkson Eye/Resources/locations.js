var win = Titanium.UI.currentWindow;
var tabs = Titanium.UI.currentTab;
var loaded = false;
var locationAlert = Titanium.UI.createAlertDialog({
    title: 'Network Error',
    message: 'Unable to load locations',
    buttonNames: ['Reload','Cancel']
});

var locationsRefreshButton = Titanium.UI.createButton({
	backgroundImage:'refresh-btn.png',
	backgroundDisabledImage:'refresh-btn.png',
	backgroundSelectedImage: 'refresh-btn-d.png',
	width:52,
	height:39
});

win.leftNavButton = locationsRefreshButton;

locationsRefreshButton.addEventListener('click', function(e)
{
 	doLocations();
});

locationAlert.addEventListener('click', function(e)
{
	if(e.index == 0){
		doLocations();
	}
	else{
		return;
	}
	
});


function doLocations(){
	Ti.Geolocation.preferredProvider = "gps";
	Ti.Geolocation.purpose = "Nearby Locations";
	Titanium.Geolocation.getCurrentPosition(function(e)
	{				
		var lng = e.coords.longitude;
		var lat = e.coords.latitude;


	var locationsView = Titanium.UI.createView({
		width:360,
		top:31,
		left:0,
		backgroundColor:'#fff'
	});

	win.add(locationsView);

	xhr = Titanium.Network.createHTTPClient();
	xhr.setTimeout(10000);
	
	xhr.onload = function() {
		loaded = true;
		var locations_data = JSON.parse(this.responseText);
		var locations_array = [];
		var nearby_array = [];

		//Begin all locations
		for (var i=0; i<locations_data.locations.length; i++){

			var dash = '';

			if(locations_data.locations[i].quickname != ''){
				dash = ' - ';
			}


			var labels = Ti.UI.createLabel({
				text: "    " + locations_data.locations[i].city + dash + locations_data.locations[i].quickname,
				font: { fontSize: 16, fontFamily: "Helvetica Neue" },
			});

			if(i == 0){
				var rows = Ti.UI.createTableViewRow({
					header:locations_data.locations[i].state,
					quickname: locations_data.locations[i].quickname,
					state: locations_data.locations[i].state,
					city: locations_data.locations[i].city,
		            street: locations_data.locations[i].street,
		            phone: locations_data.locations[i].phone,
		            fax: locations_data.locations[i].fax,
		            hours: locations_data.locations[i].hours,
		            image: locations_data.locations[i].image,
		            font:{fontSize: 16,fontFamily:'Helvetica Neue'},
		            hasChild:true
	          	});   

			}

			else if( i > 2 && locations_data.locations[i].state != locations_data.locations[i-1].state){
				var rows = Ti.UI.createTableViewRow({
					header:locations_data.locations[i].state,
					quickname: locations_data.locations[i].quickname,
					state: locations_data.locations[i].state,
					city: locations_data.locations[i].city,
		            street: locations_data.locations[i].street,
		            phone: locations_data.locations[i].phone,
		            fax: locations_data.locations[i].fax,
		            hours: locations_data.locations[i].hours,
		            image: locations_data.locations[i].image,
		            font:{fontSize: 16,fontFamily:'Helvetica Neue'},
		            hasChild:true
	          	});   
			}

			else{
				var rows = Ti.UI.createTableViewRow({
					quickname: locations_data.locations[i].quickname,
					state: locations_data.locations[i].state,
					city: locations_data.locations[i].city,
		            street: locations_data.locations[i].street,
		            phone: locations_data.locations[i].phone,
		            fax: locations_data.locations[i].fax,
		            hours: locations_data.locations[i].hours,
		            image: locations_data.locations[i].image,
		            font:{fontSize: 16,fontFamily:'Helvetica Neue'},
		            hasChild:true
	          	});   
			}

	          rows.add(labels);
	          locations_array.push(rows);
	      };

			var locationsTableView = Titanium.UI.createTableView({
			 data:locations_array
			});

		locationsTableView.addEventListener('click', function(e)
		{ 

			if (e.rowData.city)
			{
				var win = null;

					win = Titanium.UI.createWindow({
						title:e.rowData.title,
						backgroundColor:'#fff',
						barColor:'#1389d1'
					});

					var nameLabel = Titanium.UI.createLabel({
						color:'#000',
						text:e.rowData.state + " - " + e.rowData.city,
						font:{fontSize:24,fontFamily:'Helvetica Neue'},
						textAlign:'left',
						width:'auto',
						height: 'auto',
						top: 0,
						left: 0
					});
					var addressLabel = Titanium.UI.createLabel({
						color:'#256696',
						text:e.rowData.street,
						font:{fontSize: 16,fontFamily:'Helvetica Neue'},
						textAlign:'left',
						width:'auto',
						height: 'auto',
						top: 30,
						left: 0
					});
					
					
					
					var phoneLabel = Titanium.UI.createLabel({
						color:'#333',
						text:'Call: ' + e.rowData.phone + '\nFax: ' + e.rowData.fax + '\nHours: ' + e.rowData.hours,
						font:{fontSize:14,fontFamily:'Helvetica Neue'},
						textAlign:'left',
						width:'auto'
					});
					var nameView = Titanium.UI.createView({
						width:'auto',
						height:'auto',
						top: 5,
						left: 5
					});
					var phoneView = Titanium.UI.createView({
						width:'auto',
						height:50,
						top: 80,
						left: 5
					});
					var image = Titanium.UI.createImageView({
						image:e.rowData.image,
						width: 360,
						height: 'auto',
						top: 140
					});
					
					var loc1CallButton = Titanium.UI.createButton({
						backgroundImage:'phone-btn.png',
						backgroundDisabledImage:'phone-btn.png',
						backgroundSelectedImage: 'phone-btn-d.png',
						width:52,
						height:39
					});
				

					var loc1Alert = Titanium.UI.createAlertDialog({
				    title: 'Call ' + e.rowData.city + '',
				    message: e.rowData.phone,
				    buttonNames: ['Call','Cancel']
					});

					var phoneNum = parseInt(e.rowData.phone.replace(/\./g,''));


					loc1Alert.addEventListener('click', function(e)
					{
						if(e.index == 0){
							Ti.Platform.openURL('tel:' + phoneNum);
						}
						else{
							return;
						}

					});

					loc1CallButton.addEventListener('click', function(e)
					{
						loc1Alert.show();
					});

					win.rightNavButton = loc1CallButton;
					

					addressLabel.addEventListener('click',function(e){
						
						Ti.Platform.openURL("http://maps.google.com/maps?q=" + e.rowData.street + " " + e.rowData.city + " " + e.rowData.state) +"";
						
					});


					nameView.add(nameLabel);
					nameView.add(addressLabel);
					phoneView.add(phoneLabel);
					//win.add(locationFooterBar);
					win.add(image);
					win.add(nameView);
					win.add(phoneView);



				 Titanium.UI.currentTab.open(win);
			}
		});//end all locations

		//begin nearby locations
		for (var i=0; i<locations_data.locations.length; i++){

			var nearby_dash = '';

			if(locations_data.locations[i].quickname != ''){
				nearby_dash = ' - ';
			}

			var myDistance = Math.sqrt(Math.pow((111.3 * (lat - locations_data.locations[i].lat)),2) + Math.pow((71.5 * (lng - locations_data.locations[i].lng)),2)) * 1000;    

			var rows2 = Ti.UI.createTableViewRow({
				distance: myDistance,
				title: " " + locations_data.locations[i].city + nearby_dash + locations_data.locations[i].quickname ,
				quickname: locations_data.locations[i].quickname,
				state: locations_data.locations[i].state,
				city: locations_data.locations[i].city,
	            street: locations_data.locations[i].street,
	            phone: locations_data.locations[i].phone,
	            fax: locations_data.locations[i].fax,
	            image: locations_data.locations[i].image,
	            hours: locations_data.locations[i].hours,
	            font:{fontSize: 16,fontFamily:'Helvetica Neue'},
	            hasChild:true
	      	});   

	      	nearby_array.push(rows2);
	      }

	      	//sort & shorten array 
	      	nearby_array.reverse();     	
	      	nearby_array.sort(function(a,b){
	      		return  b.distance - a.distance;
	      	});
	      	nearby_array.reverse();
	      	short_nearby = nearby_array.splice(0,5);

	  		var nearbyTableView = Titanium.UI.createTableView({
				data:short_nearby
			});

		//end nearby locations

			nearbyTableView.addEventListener('click', function(e)
		{
			if (e.rowData.city)
			{
				var win = null;

					win = Titanium.UI.createWindow({
						title:e.rowData.title,
						backgroundColor:'#fff',
						barColor:'#1389d1'
					});

					var nameLabel = Titanium.UI.createLabel({
						color:'#000',
						text:e.rowData.state + " - " + e.rowData.city,
						font:{fontSize:24,fontFamily:'Helvetica Neue'},
						textAlign:'left',
						width:'auto',
						height: 'auto',
						top: 0,
						left: 0
					});
					var addressLabel = Titanium.UI.createLabel({
						color:'#256696',
						text:e.rowData.street,
						font:{fontSize: 16,fontFamily:'Helvetica Neue'},
						textAlign:'left',
						width:'auto',
						height: 'auto',
						top: 30,
						left: 0
					});
					var phoneLabel = Titanium.UI.createLabel({
						color:'#333',
						text:'Call: ' + e.rowData.phone + '\nFax: ' + e.rowData.fax + '\nHours: ' + e.rowData.hours,
						font:{fontSize:14,fontFamily:'Helvetica Neue'},
						textAlign:'left',
						width:'auto'
					});


					var nameView = Titanium.UI.createView({
						width:'auto',
						height:'auto',
						top: 5,
						left: 5
					});
					var phoneView = Titanium.UI.createView({
						width:'auto',
						height:50,
						top: 80,
						left: 5
					});
					var image = Titanium.UI.createImageView({
						image:e.rowData.image,
						width: 360,
						height: 'auto',
						top: 130
					});
	
					var loc2CallButton = Titanium.UI.createButton({
					backgroundImage:'phone-btn.png',
					backgroundDisabledImage:'phone-btn.png',
					backgroundSelectedImage: 'phone-btn-d.png',
					width:52,
					height:39
				});

					var loc2Alert = Titanium.UI.createAlertDialog({
				    title: 'Call ' + e.rowData.city + '',
				    message: e.rowData.phone,
				    buttonNames: ['Call','Cancel']
					});

					var phoneNum2 = parseInt(e.rowData.phone.replace(/\./g,''));


					loc2Alert.addEventListener('click', function(e)
					{
						if(e.index == 0){
							Ti.Platform.openURL('tel:' + phoneNum2);
						}
						else{
							return;
						}

					});

					loc2CallButton.addEventListener('click', function(e)
					{
						loc2Alert.show();
					});
					
					addressLabel.addEventListener('click',function(e){
						
						Ti.Platform.openURL("http://maps.google.com/maps?q=" + e.rowData.street + " " + e.rowData.city + " " + e.rowData.state) +"";
						
					});
					
					nameView.add(nameLabel);
					nameView.add(addressLabel);
					phoneView.add(phoneLabel);

					win.add(image);
					win.add(nameView);
					win.add(phoneView);

					win.rightNavButton = loc2CallButton;

				 Titanium.UI.currentTab.open(win);
			}
		});//end nearby locations

		var tabbarLabel = Titanium.UI.createLabel({
			backgroundColor: '#999',
			height:30,
			top:0

			});

		var locationTabBar = Titanium.UI.createTabbedBar({
		    labels:['Nearby', 'All'],
		    backgroundColor:'#999',
		    top:0,
		    height:30,
		    width:360,
			index:0
		});

		win.add(tabbarLabel);
		win.add(locationTabBar);
		locationsView.add(nearbyTableView);

	locationTabBar.addEventListener('click', function(e)
		{

			if(e.index == 0){
				locationsView.remove(locationsTableView);
				locationsView.add(nearbyTableView);
			}

			if(e.index == 1){
				locationsView.remove(nearbyTableView);
				locationsView.add(locationsTableView);
			}

		});

	};

	xhr.onerror = function(){
		locationAlert.show();
	}

	xhr.open('GET', 'http://www.clarksoneyecare.com/mobile_admin/locations_to_phone.php');
	xhr.send();
	});	
}

win.addEventListener('focus', function() 
{	
	if(!loaded){
			doLocations();
	}

});




